#include "dibapi.h"

void rectcoding(HDIB hDIB,int wRect,int hRect);
